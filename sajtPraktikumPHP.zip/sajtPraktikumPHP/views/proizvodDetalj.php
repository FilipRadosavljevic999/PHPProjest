<?php
if(!isset($_GET['id'])){
    header('Location:404.php');
}
$id=$_GET['id'];
$upit=$conn->prepare("SELECT a.idartikl,a.naziv AS artikl,a.vecaslika,a.manjaslika,a.kolicina,a.vodootpornost,c.cena,c.aktivna,m.naziv AS mehanizam,p.nazivpola,n.naziv,pr.velicina,v.vrstanaziv FROM (((((artikl AS a INNER JOIN cenovnik AS c ON a.idartikl=c.idartikl && c.aktivna=1)INNER JOIN mehanizam AS m ON a.idmehanizam=m.idmehanizam) INNER JOIN pol AS p ON a.idpol=p.idpol)INNER JOIN narukvica AS n ON a.idnarukvica=n.idnarukvica)INNER JOIN precnik AS pr ON a.idPrecnik=pr.idprecnik)INNER JOIN vrsta AS v ON a.idvrsta=v.idvrsta WHERE a.idartikl=:id LIMIT 1");
$upit->bindParam(":id",$id);
$upit->execute();
$rezultat=$upit->fetchAll();


?>
<section class="header_text sub">
    <h4><span>Detalji Proizvoda</span></h4>
</section>
<section class="main-content">
    <div class="row">
        <div class="span12">
						<div class="row">
                            <?php foreach ($rezultat as $r):?>
                                <div class="span4">
								<a><img alt="" src="views/assets/img/<?=$r->vecaslika?>"/></a>
                            </div>
							    <div class="span5">
								<address>
									<strong>Brand:</strong> <span><?=$r->artikl?></span><br>
									<strong>Waterproof:</strong> <span><?=$r->vodootpornost?></span><br>
									<strong>Mehanizam:</strong> <span><?=$r->mehanizam?></span><br>
									<strong>Gender:</strong> <span><?=$r->nazivpola?></span><br>
                                    <strong>Strap:</strong> <span><?=$r->naziv?></span><br>
                                    <strong>Case dimatere:</strong> <span><?=$r->velicina?>mm</span><br>
								</address>
								<h4><strong>Price: <?=$r->cena?> $</strong></h4>
							</div>
                            <?php endforeach;?>
						</div>

					</div>
        <br>
        <?php
            if(isset($_SESSION['korisnik'])):?>
                <div class="span12 center">
                    <h4><span>Order product</span></h4>
                </div>

                <div class="span12 center">
                    <?php foreach ($rezultat as $ra):?>
                        <form action="models/order.php" method="post">
                            <input type="hidden" name="next" value="/">
                            <fieldset>
                                <div class="control-group">
                                    <label class="control-label">First Name:</label>
                                    <div class="controls">
                                        <input type="text" placeholder="Please enter First name" id="email" name="ime" class="input-xlarge">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Last name: </label>
                                    <div class="controls">
                                        <input type="text" placeholder="Pleas enter last name" id="email" name="prezime" class="input-xlarge">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Address: </label>
                                    <div class="controls">
                                        <input type="text" placeholder="Please enter address" id="email" name="adresa" class="input-xlarge">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Phone Number: </label>
                                    <div class="controls">
                                        <input type="text" placeholder="Please enter phone number " id="email" name="broj" class="input-xlarge">
                                    </div>
                                </div>
                                <div class="control-group">

                                    <div class="controls">
                                        <input type="hidden" placeholder="Unesi broj telefona" id="email" name="idartikl" value=<?= $ra->idartikl?> class="input-xlarge">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <input tabindex="3" class="btn btn-inverse large" type="submit" name="poruka" value="Order">
                                    <hr>
                                </div>
                            </fieldset>
                        </form>
                    <?php endforeach;?>
                    <ul>
                        <?php
                        if(isset($_SESSION['orderOk'])):
                            ?>
                            <li><?=$_SESSION['orderOk']?></li>

                        <?php endif;
                        unset($_SESSION['orderOk']);
                        if(isset($_SESSION['orderError'])):
                            ?>
                            <?php foreach ($_SESSION['orderError'] as $e):?>
                            <li><?=$e?></li>
                        <?php endforeach;?>
                        <?php endif;
                        unset($_SESSION['orderError']);
                        ?>
                    </ul>
                </div>
            <?php
        else:
            ?>
            <div class="span12 center">
                <h4><span>You must be logged in to order </span></h4>
            </div>
        <?php
         endif;
        ?>





    </div>




</section>