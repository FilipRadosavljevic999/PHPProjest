<?php
//zabeleziPristupStranici();
?>
<?php
if(!isset($_GET['id'])){
    header('Location:404.php');
}
$id=$_GET['id'];
$upit=$conn->prepare("SELECT a.idartikl,a.naziv AS artikl,a.vecaslika,a.manjaslika,a.kolicina,a.vodootpornost,c.cena,c.aktivna,m.naziv AS mehanizam,p.nazivpola,n.naziv,pr.velicina,v.vrstanaziv FROM (((((artikl AS a INNER JOIN cenovnik AS c ON a.idartikl=c.idartikl)INNER JOIN mehanizam AS m ON a.idmehanizam=m.idmehanizam) INNER JOIN pol AS p ON a.idpol=p.idpol)INNER JOIN narukvica AS n ON a.idnarukvica=n.idnarukvica)INNER JOIN precnik AS pr ON a.idPrecnik=pr.idprecnik)INNER JOIN vrsta AS v ON a.idvrsta=v.idvrsta WHERE a.idartikl=:id && c.aktivna=1 LIMIT 1");
$upit->bindParam(":id",$id);
$upit->execute();
$rezultat=$upit->fetchAll();


?>
<section class="main-content">
    <div class="row">
        <div class="span12">
            <div class="row">
                <div class="span12 center">
                    <h3 class="text-left">Edit product:</h3>
                        <div class="block">
                            <?php
                                foreach ($rezultat as $r):
                            ?>
                            <form action="models/izmeniproizvod.php" method="post" class="form-stacked" enctype="multipart/form-data">
                                <fieldset>
                                    <div class="span12">
                                        <div class="span4 left">

                                            <div class="control-group left">
                                                <label class="control-label">Name:</label>
                                                <div class="controls">
                                                    <input type="text" value="<?=$r->artikl?>" name="naziv" class="input-xlarge">
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label">Quantity:</label>
                                                <div class="controls">
                                                    <input type="text" value="<?=$r->kolicina?>" name="kol" class="input-xlarge">
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label ">WaterProof:</label>
                                                <div class="controls">
                                                    <input type="text" value="<?=$r->vodootpornost?>" name="vod" class="input-xlarge">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 center">

                                            <div class="control-group left">
                                                <label class="control-label ">Strap:</label>
                                                <div class="controls">
                                                    <select id="narukvica" name="narukvica">
                                                        <option>Select Strap</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label ">Mechanism:</label>
                                                <div class="controls">
                                                    <select id="mehanizam" name="mehanizam">
                                                        <option>Select Mechanism</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label ">Gender:</label>
                                                <div class="controls">
                                                    <select id="pol" name="pol">
                                                        <option>Select Gender</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span3 right" >

                                            <div class="control-group left">
                                                <label class="control-label ">Case diameter:</label>
                                                <div class="controls">
                                                    <select id="precnik" name="precnik" value="<?=$r->idprecnik?>">
                                                        <option>Select Case diameter </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label ">Brand:</label>
                                                <div class="controls">
                                                    <select id="vrsta" name="vrsta">
                                                        <option>Select brand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="control-group left">
                                                <label class="control-label ">Price:</label>
                                                <div class="controls">
                                                    <input type="text" value="<?=$r->cena?>" name="cena">

                                                </div>
                                            </div>
                                            <div class="controls">
                                                <input type="hidden" placeholder="" id="email" name="idartikl" value=<?= $r->idartikl?> class="input-xlarge">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <hr>
                                        <div class="actions center">
                                            <input tabindex="9" class="btn btn-inverse large" name="dugmeIzmeni" type="submit" value="Edir Product">
                                        </div>
                                    </div>


                                </fieldset>
                            </form>
                            <?php
                            endforeach;
                            ?>
                            <ul>
                                <?php


                                if(isset($_SESSION['uspeloizmeni'])):?>
                                    <li><?=$_SESSION['uspeloizmeni']?></li>
                                <?php
                                endif;
                                unset($_SESSION['uspeloizmeni']);
                                ?>
                                <?php if(isset($_SESSION['greskaizmena'])):
                                    foreach ($_SESSION['greskaizmena'] as $g):?>
                                        <li><?=$g?></li>
                                    <?php
                                    endforeach;
                                endif;
                                unset($_SESSION['greskaizmena'])
                                ?>


                            </ul>


                        </div>

                </div>


            </div>

        </div>
    </div>
</section>
<script src="views/assets/js/izmena.js"></script>


