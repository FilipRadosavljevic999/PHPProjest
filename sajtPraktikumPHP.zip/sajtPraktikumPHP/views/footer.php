<section id="footer-bar">
    <div class="row">
        <div class="span12 left">
            <h4>Navigation</h4>
            <ul class="nav">
                <?php foreach($upit as $u):?>
                    <li><a href="index.php?page=<?=$u->putanja?>" style="font-size: 20px;"><?=$u->naziv?></a></li>
                <?php endforeach;?>
            </ul>
        </div>

        <div class="span12 right">
            <a href="models/exportWord.php" class="text-warning" >
            EXPORT TO WORD
            </a>
            <br>
            <a href="Dokumentacija Sajt.docx" class="text-warning" >
                Dokumentacija
            </a>

        </div>
    </div>
</section>
<section id="copyright">
    <span>Copyright 2013 bootstrappage template  All right reserved.</span>
</section>
