<script src="views/assets/themes/js/common.js"></script>
<script src="views/assets/themes/js/jquery.flexslider-min.js"></script>

