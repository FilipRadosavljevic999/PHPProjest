<?php
zabeleziPristupStranici('prodavnica');
?>

<section class="header_text sub">

    <h4><span>Products</span></h4>
</section>
<section class="main-content">

    <div class="row">
        <div class="span9">
            <ul class="thumbnails listing-products" id="proizvodi">

            </ul>
            <hr>
            <div class="pagination pagination-small pagination-centered">
                <ul id="paginacija">

                </ul>
            </div>
        </div>

        <div class="span3 col">

            <div class="block">
                <h3>Filter</h3>
                <form action="#" method="post">
                    <label>Search</label>
                    <input type="text" id="pretraga"class="form-inline">
                    <label>Min Price</label>
                    <input type="number" id="min"class="form-inline">
                    <label>Max Price</label>
                    <input type="number" id="max"class="form-inline">
                    <button class="button  btn-block" id="filter">Filter</button>

                </form>
            </div>

        </div>
    </div>
</section>
<script src="views/assets/js/shop.js"></script>