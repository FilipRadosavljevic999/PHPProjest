<?php
if (!isset($_SESSION['korisnik'])) {
    $upit = $conn->query("SELECT m.putanja,m.naziv FROM (meni AS m INNER JOIN meniuloga as mn ON m.idmeni=mn.idmeni)INNER JOIN uloga AS u ON mn.iduloga=u.id WHERE u.id=1")->fetchall();

} else {
    if ($_SESSION['korisnik']->nazivuloge == "korisnik") {
        $upit = $conn->query("SELECT m.putanja,m.naziv FROM (meni AS m INNER JOIN meniuloga as mn ON m.idmeni=mn.idmeni)INNER JOIN uloga AS u ON mn.iduloga=u.id WHERE u.id=2")->fetchall();
    } else {
        $upit = $conn->query("SELECT m.putanja,m.naziv FROM (meni AS m INNER JOIN meniuloga as mn ON m.idmeni=mn.idmeni)INNER JOIN uloga AS u ON mn.iduloga=u.id WHERE u.id=3")->fetchall();
    }
}
?>
<section class="navbar main-menu">
    <div class="navbar-inner main-menu">
        <nav id="menu" class="pull-right">
            <ul>
                <!--<li><a href="./products.html">Woman</a>
                    <ul>
                        <li><a href="./products.html">Lacinia nibh</a></li>
                        <li><a href="./products.html">Eget molestie</a></li>
                        <li><a href="./products.html">Varius purus</a></li>
                    </ul>
                </li>
                <li><a href="./products.html">Man</a></li>
                <li><a href="./products.html">Sport</a>
                    <ul>
                        <li><a href="./products.html">Gifts and Tech</a></li>
                        <li><a href="./products.html">Ties and Hats</a></li>
                        <li><a href="./products.html">Cold Weather</a></li>
                    </ul>
                </li>
                <li><a href="./products.html">Hangbag</a></li>
                <li><a href="./products.html">Best Seller</a></li>
                <li><a href="./products.html">Top Seller</a></li>-->
                <?php foreach($upit as $u):?>
                    <li><a href="index.php?page=<?=$u->putanja?>" style="font-size: 20px;"><?=$u->naziv?></a></li>
                <?php endforeach;?>
            </ul>
        </nav>
    </div>
</section>
