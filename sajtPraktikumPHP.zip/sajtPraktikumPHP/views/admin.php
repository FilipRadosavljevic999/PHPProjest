<?php
if(!isset($_SESSION['korisnik']) && $_SESSION['korisnik']['nazivuloge']!="admin"){
    header('Location:404.php');
}
zabeleziPristupStranici('admin');
?>

<section class="main-content">
    <div class="row">
        <br>
        <div class="span12 center">

         <h3 class="text-left">Users:</h3>
         <div class="block">
             <table class="table table-bordered table-hover  ">
                 <thead>
                 <tr>
                     <td>Rb</td>
                     <td>First Name</td>
                     <td>Last Name</td>
                     <td>Email</td>
                     <td>Delete user</td>
                 </tr>
                 </thead>
                 <tbody id="korisnici">

                 </tbody>
             </table>

         </div>

     </div>
        <br>
        <div class="span12 center">

            <h3 class="text-left">Products:</h3>
            <div class="block">
                <table class="table table-bordered table-hover ">
                    <thead>
                    <tr>
                        <td>Rb</td>
                        <td>Image</td>
                        <td>Name</td>
                        <td>Price</td>
                        <td>Edit product</td>
                        <td>Delete product</td>
                    </tr>
                    </thead>
                    <tbody id="proizvodi">

                    </tbody>
                </table>

            </div>

        </div>
        <br>
        <div class="span12 center">

            <h3 class="text-left">Orders:</h3>
            <div class="block">
                <table class="table table-bordered table-hover  ">
                    <thead>
                    <tr>
                        <td>Rb</td>
                        <td>Image product</td>
                        <td>Name Product</td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Address</td>
                        <td>Phone number</td>
                        <td>Date</td>
                        <td>Email</td>
                        <td>Price</td>
                        <td>Delete Order</td>
                    </tr>
                    </thead>
                    <tbody id="order">

                    </tbody>
                </table>

            </div>

        </div>
        <br>
        <div class="span12 center">

            <h3 class="text-left">Add product:</h3>
            <div class="block">
                <form action="models/dodajproizvod.php" method="post" class="form-stacked" enctype="multipart/form-data">
                        <fieldset>
                            <div class="span12">
                                <div class="span4 left">
                                    <div class="control-group left">
                                        <label class="control-label">Select image:</label>
                                        <div class="controls">
                                            <input type="file" placeholder="Izaberi sliku" name="slika" class="input-xlarge">
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label">Name:</label>
                                        <div class="controls">
                                            <input type="text" placeholder="Please enter name" name="naziv" class="input-xlarge">
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label">Quantity:</label>
                                        <div class="controls">
                                            <input type="text" placeholder="Please Enter Quantity" name="kol" class="input-xlarge">
                                        </div>
                                    </div>
                                </div>
                                <div class="span4 center">
                                    <div class="control-group left">
                                        <label class="control-label ">Waterproof:</label>
                                        <div class="controls">
                                            <input type="text" placeholder="Please Enter Waterproof" name="vod" class="input-xlarge">
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label ">Strap:</label>
                                        <div class="controls">
                                          <select id="narukvica" name="narukvica">
                                              <option>Select strap</option>
                                          </select>
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label ">Mechanism:</label>
                                        <div class="controls">
                                            <select id="mehanizam" name="mehanizam">
                                                <option>Select mechanism</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="span3 right" >
                                    <div class="control-group left">
                                        <label class="control-label ">Gender:</label>
                                        <div class="controls">
                                            <select id="pol" name="pol">
                                                <option>Select gender</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label ">Case diameter:</label>
                                        <div class="controls">
                                            <select id="precnik" name="precnik">
                                                <option>Select case diameter</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label ">Brand:</label>
                                        <div class="controls">
                                            <select id="vrsta" name="vrsta">
                                                <option>select brand</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="control-group left">
                                        <label class="control-label ">Price:</label>
                                        <div class="controls">
                                           <input type="text" placeholder="Unesi cenu" name="cena">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="control-group left">
                                <hr>
                                <div class="actions center">
                                    <input tabindex="9" class="btn btn-inverse large" name="dugmeDodaj" type="submit" value="Add product">
                                </div>
                            </div>


                        </fieldset>
                </form>

                <ul>
                    <?php if(isset($_SESSION['uspeloDodaj'])):?>
                    <li><?=$_SESSION['uspeloDodaj']?></li>
                    <?php
                    endif;
                    unset($_SESSION['uspeloDodaj']);
                    ?>
                    <?php if(isset($_SESSION['greskeDodaj'])):
                        foreach ($_SESSION['greskeDodaj'] as $g):?>
                        <li><?=$g?></li>
                    <?php
                    endforeach;
                    endif;
                    unset($_SESSION['greskeDodaj'])
                    ?>


                </ul>


            </div>

        </div>
        <br>
        <div class="span12 center">

            <h3 class="text-left">Site stats:</h3>
            <div class="block">
                <table class="table table-bordered table-hover  ">
                    <thead>
                    <tr>
                        <td>Home</td>
                        <td>Shop</td>
                        <td>Register and Login</td>
                        <td>Admin</td>

                    </tr>
                    </thead>
                    <tbody id="prikaz">

                    </tbody>
                </table>

            </div>

        </div>

    </div>
</section>
<script src="views/assets/js/admin.js"></script>