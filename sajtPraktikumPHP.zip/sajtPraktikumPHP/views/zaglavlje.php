<head>
    <meta charset="utf-8">
    <title>Bootstrap E-commerce Templates</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
    <!-- bootstrap -->
    <link href="views/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">

    <link href="views/assets/themes/css/bootstrappage.css" rel="stylesheet"/>

    <!-- global styles -->
    <link href="views/assets/themes/css/flexslider.css" rel="stylesheet"/>
    <link href="views/assets/themes/css/main.css" rel="stylesheet"/>

    <!-- scripts -->
    <script src="views/assets/themes/js/jquery-1.7.2.min.js"></script>
    <script src="views/assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="views/assets/themes/js/superfish.js"></script>
    <script src="views/assets/themes/js/jquery.scrolltotop.js"></script>
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <script src="views/assets/js/respond.min.js"></script>
    <![endif]-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
