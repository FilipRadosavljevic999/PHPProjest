<?php
zabeleziPristupStranici('login');
?>

<section class="main-content">
    <div class="row">
        <div class="span5">
            <h4 class="title"><span class="text"><strong>Sign up </strong></span></h4>
            <form action="models/logovanje.php" method="post">
                <input type="hidden" name="next" value="/">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label">Username</label>
                        <div class="controls">
                            <input type="text" placeholder="Please enter username" id="email" name="email" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Password </label>
                        <div class="controls">
                            <input type="password" placeholder="Please enter password" id="email" name="sifra" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <input tabindex="3" class="btn btn-inverse large" type="submit" name="logindugme" value="Sign up">
                        <hr>

                    </div>
                </fieldset>
            </form>
            <ul>
                    <?php
                    if(isset($_SESSION['greskalogin'])):
                    ?>
                    <li><?=$_SESSION['greskalogin']?>
                        <?php unset($_SESSION['greskalogin']);
                        ?>
                        <?php endif;?>
                        <?php
                        if(isset($_SESSION['greskalogovanje'])):
                        foreach($_SESSION['greskalogovanje'] as $g):?>
                    <li><?=$g?></li>
                <?php unset($_SESSION['greskalogovanje']);?>
                <?php
                endforeach;
                endif;
                ?>
                </ul>

        </div>
        <div class="span7">
            <h4 class="title"><span class="text"><strong>Register</strong></span></h4>
            <form action="models/registrovanje.php" method="post" class="form-stacked">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label">First name</label>
                        <div class="controls">
                            <input type="text" placeholder="Please enter First name" name="ime" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Prezime:</label>
                        <div class="controls">
                            <input type="text" placeholder="Please enter Last name" name="prezime" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"> Email:</label>
                        <div class="controls">
                            <input type="text" placeholder="Please enter email" name="emailreg" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"> Password:</label>
                        <div class="controls">
                            <input type="password" placeholder="Please enter password" name="password" class="input-xlarge">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Confirm pasword:</label>
                        <div class="controls">
                            <input type="password" placeholder="Please confirm password" name="potvrda" class="input-xlarge">
                        </div>

                    <hr>
                    <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Register"></div>
                </fieldset>
            </form>
            <ul>
                <?php
                if(isset($_SESSION['uspelareg'])):?>
                <li><?=$_SESSION['uspelareg']?>
                    <?php unset($_SESSION['uspelareg']);
                    ?>
                    <?php endif?>

                    <?php
                    if(isset($_SESSION['greskabaze'])):
                    ?>
                <li><?=$_SESSION['greskabaze']?>
                    <?php unset($_SESSION['greskabaze']);
                    ?>
                    <?php endif;?>
                    <?php
                    if(isset($_SESSION['greskereg'])):
                    foreach($_SESSION['greskereg'] as $g):?>
                <li><?=$g?></li>
            <?php unset($_SESSION['greskereg']);?>
            <?php
            endforeach;
            endif;
            ?>

            </ul>
        </div>

    </div>
</section>
