
<?php
$autor=executeQuery("SELECT * FROM autor LIMIT 1");
?>
<section class="main-content">


    <div class="row">
        <div class="span12">
            <div class="row">
                <div class="span12">
                    <?php
                     foreach ($autor as $a):
                    ?>
                    <img src="views/assets/img/<?=$a->slika?>" alt="slika"  />
                     <p><?=$a->ime?></p>
                    <?php
                     endforeach;
                    ?>
                </div>
            </div>

        </div>
    </div>
</section>
