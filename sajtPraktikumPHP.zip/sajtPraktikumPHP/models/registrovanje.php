<?php
ob_start();
session_start();
$greske=[];
$dugme=$_POST["registerdugme"];
if(!isset($dugme)){
    header('Location:404.php');
};
if(!isset($_POST['ime'])){
    $greske[]="Morate uneti ime";
}
if(!isset($_POST['prezime'])){
    $greske[]="Morate uneti prezime";
}
if(!isset($_POST['emailreg'])){
    $greske[]="Morate uneti email";
}
if(!isset($_POST['password'])){
    $greske[]="Morate uneti lozinku";
}
if(!isset($_POST['potvrda'])){
    $greske[]="Morate uneti potvrdu lozinke";
}
$ime=$_POST["ime"];
$Prezime=$_POST["prezime"];
$email=$_POST["emailreg"];
$pass=$_POST["password"];
$passconfirm=$_POST["potvrda"];

$regexIme = "/^[A-ZČĆŠĐŽ][a-zčćšđž]{1,14}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{1,19}){0,}$/";
$regexLozinka = "/^.{4,50}$/";
define("ULOGA",2);
if(!preg_match($regexIme, $ime)){
    $greske[] = "Please enter valid First name";

};
if(!preg_match($regexIme, $Prezime)){
    $greske[] = "Please enter valid Last name";
};
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $greske[] = "Please enter valid email";
};
if($pass!=$passconfirm){
    $greske[]="Password is not same";
};
if(!preg_match($regexLozinka, $pass)){
    $greske[] = "Please enter valid password";
}
include("../config/connection.php");
if(count($greske)==0){
    $upit="INSERT INTO korisnici VALUES (NULL, :ime, :prezime, :email, :pass, 1,2 )";
    $pass=md5($pass);
    $upis=$conn->prepare($upit);
    $upis->bindParam(":ime",$ime);
    $upis->bindParam(":prezime",$Prezime);
    $upis->bindParam(":email",$email);
    $upis->bindParam(":pass",$pass);
    try{
        $uneto=$upis->execute();
        header("Location:../index.php?page=register");
        $_SESSION['uspelareg']="Register successful";
    }
    catch(PDOException $ex){
        $_SESSION['greskabaze']="Already exist user";
        header('Location:../index.php?page=register');

    }
}
else{
    $_SESSION['greskereg']=$greske;
    header('Location:../index.php?page=register');
}
